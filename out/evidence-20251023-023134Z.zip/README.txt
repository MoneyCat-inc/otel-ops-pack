BossCat Evidence Pack
=====================
Generated: 20251023-023134Z
Collector: signoz-otel-collector
Gate ID: GATE-2025-10-08-234500

Contents:
- gate_verification.json: Latest verification results
- gate_decision.json: Gate decision document
- GATE_STATUS.md: Current gate status
- IONA_ERRORS.md: Error ledger
- service_otelcol.txt: Windows collector service state
- docker_ps.txt: Docker container state
- collector_logs_10m.txt: Collector logs (last 10 minutes)

This evidence pack can be provided to auditors or incident responders.
